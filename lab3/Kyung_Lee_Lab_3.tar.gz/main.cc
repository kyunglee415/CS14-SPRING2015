//Kyung Lee
//861102411
//4/27/15

#include <iostream>
#include "lab3.h"
#include <stack>

using namespace std;

// void showTowerStates(int n, stack<int>& A, stack<int>& B, stack<int>& C) {
//     string arr[] = {"A", "B", "C"};
//     showTowerStates2(n, A, B, C, arr);
// }
// template <typename T>
// void showTowerStates2(int n, stack<T>& A, stack<T>& B, stack<T>& C, string arr[]) {
//     string string0 = arr[0];
//     string string1 = arr[1];
//     string string2 = arr[2];
//     if (n == 0) {
//         cout << "Moved value " << n << " from peg " << arr[0] << " to " << arr[2] << endl;
//     }
//     else {
//         arr[1] = string2;
//         arr[2] = string1;
//         showTowerStates2(n - 1, A, C, B, arr);
//         cout << "Moved value " << n << " from peg " << arr[0] << " to " << arr[1] << endl;
//         arr[0] = string1;
//         arr[1] = string0;
//         arr[2] = string2;
//         showTowerStates2(n - 1, C, B, A, arr);
//     }
// }
// template <typename T>
// void showTowerStates(int n, stack<T>& A, stack<T>& B, stack<T>& C) {
//     string arr[] = {"A", "B", "C"};
//     showTowerStates2(n, A, B, C, arr);
// }


int main() {
    
    TwoStackFixed first(8, 3);
    
    first.pushStack2(2);
    first.pushStack2(5);
    first.pushStack2(7);
    first.pushStack2(7);
    first.pushStack2(7);
    // first.pushStack2(7);
    
    // first.popStack2();
    // first.popStack2();
    // first.popStack2();
    // first.popStack2();
    // first.popStack2();
    // first.popStack2();
    // first.pushStack2(8);
    // first.pushStack2(7);
    //     first.pushStack2(7);
    //     first.pushStack2(7);
    //     first.pushStack2(7);
    // if (first.isFullStack1()) {
    //     cout << "hi" << endl;
    // }
    // else if (first.isEmptyStack1()) {
    //     cout << "bye" << endl;
    // }
    
    
    // first.pushStack1(6);
    // first.pushStack1(6);
    // first.pushStack1(6);
    //first.pushStack1(6);
    //first.popStack1();
    //     if (first.isFullStack1()) {
    //     cout << "hi" << endl;
    // }
    // else if (first.isEmptyStack1()) {
    //     cout << "bye" << endl;
    // }
    
    first.display();
    
    TwoStackOptimal second(8);
    
    second.pushFlexStack1(7);
    second.pushFlexStack1(7);
    second.pushFlexStack1(7);
    second.pushFlexStack1(7);
    second.pushFlexStack1(7);
    second.pushFlexStack1(7);
    // second.pushFlexStack1(7);
    // second.pushFlexStack1(7);
    // second.pushFlexStack1(7);
    
    second.display();
    
    // stack<int> first;
    // stack<int> second;
    // stack<int> third;
    
    // // // first.push(5);
    // // // first.push(8);
    // // // first.push(3);
    // // // first.push(5);
    //showTowerStates(5, first, second, third);
    
    
    return 0;
}