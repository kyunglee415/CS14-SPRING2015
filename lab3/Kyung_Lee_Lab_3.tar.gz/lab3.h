//Kyung Lee
//861102411
//4/27/15

#include <iostream>
#include <stack>

using namespace std;
//LIFO
//template<typename T>
class TwoStackFixed {
    private:
        int *arr;
        int top1;
        int top2;
        int sz;
        int max;
        int check;
    public:
        TwoStackFixed() :arr(0), top1(0), top2(0), sz(0), max(0) {}
        
        //template<typename T>
        TwoStackFixed(int size, int maxtop) {
            
            int *temp = new int[size];
            arr = temp;
            
            top2 = size - 1;
            top1 = 0;
            sz = size;
            max = maxtop;
            check = size;
        }
        template<typename T>
        void pushStack1(T value) {
            if (sz == 0) {
                cout << "Error: Empty Set." << endl;
                return;
            }
            if (max == 0) {
                cout << "Error: OVERFLOW." << endl;
                return;
            }
            if (top1 < max) {
                arr[top1] = value;
                ++top1;
            }
            else {
                cout << "Error: OVERFLOW." << endl;
            }
            //cout << "top1 " << top1 << endl;
        }
        template<typename T>
        void pushStack2(T value) {
            if (sz == 0) {
                cout << "Error: Empty Set." << endl;
                return;
            }            
            if (max == 0) {
                if (top2 >= 0) {
                    arr[top2] = value;
                    --top2;
                }
                else {
                    cout << "Error: Overflow." << endl;
                    return;
                }
            }
            else if (top2 != max - 1) {
                arr[top2] = value;;
                --top2;
            }
            else {
                cout << "Error: Overflow." << endl;
            }
            //cout << "top2 " << top2 << endl;
        }
        template<typename T>
        T popStack1() {
            if (sz == 0 || max == 0) {
                cout << "Error: Empty Set." << endl;
                exit(-1);
            }
            
            T hold = 0;
            if (top1 != 0) {
                if (top1 == max) {
                    --top1;
                }
                hold = arr[top1];
                arr[top1] = 0;
                --top1;
            }
            else {
                cout << "Error: Cannot delete nothing." << endl;
                exit(-1);
                
            }
            return hold;
        }
        template<typename T>
        T popStack2() {
            if (sz == 0) {
                cout << "Error: Empty Set." << endl;
                exit(-1);
            }
            T hold;
            if (top2 < sz) {
                if (top2 == max - 1) {
                    ++top2;
                }
                hold = arr[top2];
                arr[top2] = 0;
                ++top2;
            }
            else {
                cout << "Error: Cannot delete nothing." << endl;
                exit(-1);
            }
            return hold;
        }
        bool isFullStack1() {
            if (top1 == max) {
                return true;
            }
            
            return false;
        }
        bool isFullStack2() {
            if (top2 == max) {
                return true;
            }
            
            return false;
        }
        bool isEmptyStack1() {
            if (sz == 0) {
                return false;
            }
            if (top1 != 0 && arr[top1] != 0) {
                return false;
            }
            
            return true;
        }
        bool isEmptyStack2() {
            if (sz == 0) {
                return false;
            }
            if (top2 != sz - 1 && arr[top2] != 0) {
                return false;
            }
            
            return true;
        }
        void display() {
            if (sz == 0) {
                cout << "Error: Empty Set." << endl;
                return;
            }
            for (int i = 0; i < sz; ++i) {
                cout << arr[i] << " ";
            }
            cout << endl;
        }
};

//template<typename T>
class TwoStackOptimal {
    
    private:
        int *arr;
        int sz;
        int top1;
        int top2;
        
    public:
        
        //template<typename T>
        TwoStackOptimal(int size) {
            sz = size;
            
            int *temp = new int[size];
            arr = temp;
            top1 = -1;
            top2 = sz;
        }
        template<typename T>
        void pushFlexStack1(T value) {
            if (sz == 0) {
                cout << "Error: Empty Set." << endl;
                return;
            }
            if (top1 < top2 - 1) {
                ++top1;
                arr[top1] = value;
            }
            else {
                cout << "Error: Stack Overflow." << endl;
                return;
            }
        }
        template<typename T>
        void pushFlexStack2(T value) {
            if (sz == 0) {
                cout << "Error: Empty Set." << endl;
                return;                
            }
            if (top1 < top2 - 1) {
                --top2;
                arr[top2] = value;
            }
            else {
                cout << "Error: Stack Overflow." << endl;
                return;                
            }
        }
        template<typename T>
        T popFlexStack1() {
            if (sz == 0) {
                cout << "Error: Empty Set." << endl;
                exit(-1);
            }
            if (top1 >= 0) {
                T hold = arr[top1];
                --top1;
                return hold;
            }
            else {
                cout << "Error: Stack Underflow." << endl;
                exit(-1);
            }
        }
        template<typename T>
        T popFlexStack2() {
            if (sz == 0) {
                cout << "Error: Empty Set." << endl;
                exit(-1);
            }
            if (top2 < sz) {
                T hold = arr[top2];
                ++top2;
                return hold;
            }
            else {
                cout << "Error: Stack Underflow." << endl;
                exit(-1);
            }
        }
        bool isFullStack1() {
            if (top1 >= top2 - 1) {
                return true;
            }
            return false;
        }
        bool isFullStack2() {
            if (top1 >= top2 - 1) {
                return true;
            }
            return false;
        }
        bool isEmptyStack1() {
            if (top1 == -1) {
                return true;
            }
            return true;
        }
        bool isEmptyStack2() {
            if (top2 == sz) {
                return true;
            }
            return false;
        }
        void display() {
            if (sz == 0) {
                cout << "Error: Empty Set." << endl;
                return;
            }
            for (int i = 0; i < sz; ++i) {
                cout << arr[i] << " ";
            }
            cout << endl;
        }
};

template <typename T>
void showTowerStates2(int n, stack<T>& A, stack<T>& B, stack<T>& C, string arr[]) {
    string string0 = arr[0];
    string string1 = arr[1];
    string string2 = arr[2];
    if (n == 0) {
        cout << "Moved value " << n << " from peg " << arr[0] << " to " << arr[2] << endl;
    }
    else {
        arr[1] = string2;
        arr[2] = string1;
        showTowerStates2(n - 1, A, C, B, arr);
        cout << "Moved value " << n << " from peg " << arr[0] << " to " << arr[1] << endl;
        arr[0] = string1;
        arr[1] = string0;
        arr[2] = string2;
        showTowerStates2(n - 1, C, B, A, arr);
    }
}
template <typename T>
void showTowerStates(int n, stack<T>& A, stack<T>& B, stack<T>& C) {
    string arr[] = {"A", "B", "C"};
    showTowerStates2(n, A, B, C, arr);
}