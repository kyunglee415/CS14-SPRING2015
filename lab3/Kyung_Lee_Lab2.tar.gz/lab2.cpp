//Kyung Lee
//861102411
//4/20/15

#include <iostream>
#include <forward_list>
#include <cmath>

using namespace std;

class Node {
    public:
        int data;
        Node *next;
        Node() : data(0), next(0) {}
};

class List {
    private:
        Node *head;
        Node *tail;
        
    public:
        List() : head(0), tail(0) {}
        
        int size() {
            Node *temp = head;
            int size = 0;
            while (temp != NULL) {

                size = size + 1;
                temp = temp->next;
            }
            return size;
        }
        
        //inserts a new value of any type in the list 
        void push( int Val ) {
            //cout << "hi" << endl;
            Node *temp;

            //cout << "eofwef" << endl;
            if (head == NULL) {
                //cout << "pkpokokpo" << endl;
                temp = new Node();
                temp->next = NULL;
                head = temp;
                tail = temp;
                temp->data = Val;
            }
            else {
                //cout << "efjoef" << endl;
                temp = new Node();
                temp->data = Val;
                tail->next = temp;
                temp->next = NULL;
                tail = temp;
            }
        }
        
        //swaps the nodes all together, not just data switching
        void elementSwap(int pos) {
            if (head == NULL) {
                cout << "Error: empty list." << endl;
                return;
            }
            else if (pos >= (size() - 1)) {
                cout << "Error: out of range, Pos is too big." << endl;
                return;
            }
            else {
                Node *temp = head;
                Node *temp2;
                Node *temp3;
    
                for (int i = 0; i < (pos - 1); ++i) {
                    temp = temp->next;
                }
                
                temp2 = temp->next;
                temp3 = temp2->next;
                
                temp->next = temp3;
                temp2->next = temp3->next;
                temp3->next = temp2;
            }
        }
        
        //displays list, head to tail
        void display() const {
            Node *print = head;
            while (print != NULL) {

                cout << print->data;
                print = print->next;
            }
        }
};

bool isPrime( int i ) {
    if (i == 0 || i == 1) {
        //cout << "no" << endl;
        return false;
    }
    
    for (int j = i - 1; j != 1; --j ) {

        if (i % j == 0) {
            //cout << "true" << endl;
            return true;
        }
        
    }
    //cout << "no2" << endl;
    return false;
}

int primeCount( forward_list<int> lst ) {
    
    int primeNum = 0;
    
    if (lst.empty()) {
        primeNum = 0;
        return primeNum;
    }
    if (isPrime(lst.front())) {
        //primeNum = primeNum + 1;
        lst.pop_front();
        return 1 + primeCount(lst);
    }
    
    else {
        lst.pop_front();
        return primeCount(lst);
    }
    return primeNum;
}
// int main() {
//     // isPrime(4);
//     // forward_list<int> myList = {4, 6, 8, 10, 11, 12, 13};
//     // forward_list<int> yourList = {2, 3, 4};
//     // cout << primeCount(myList) << endl;
    
//     // List ip;
//     // ip.push(1);
//     // ip.push(3);
//     // ip.push(6);
//     // ip.push(7);
//     // ip.push(8);
//     // ip.push(9);
//     // cout << "hi " << endl;
//     // ip.display();
//     // cout << endl;
    
//     // cout << ip.size() << endl;
    
//     // ip.elementSwap(4);
//     // ip.display();
//     // cout << endl;
    
//     forward_list<int> myList = {4, 6, 8, 10, 11, 12, 13};
//     forward_list<int> yourList = {2, 4, 6, 7, 8};
    
//     //listCopy(myList, yourList);
    
//     printLots(myList, yourList);
    
    
//     return 0;
// }