//Kyung Lee
//861102411
//4/20/15

#include <iostream>
//#include <list>
#include <forward_list>

using namespace std;

//typedef int Type;
template <typename Type>
void listCopy( forward_list <Type> L, forward_list <Type>& P ) {
    
    typename forward_list<Type>::iterator it;
    typename forward_list<Type>::iterator that;
    int counter = 0;

    for (it = P.begin(); it != P.end(); ++it) {
        counter = counter + 1;
    }
    it = P.begin();
    
    for (int i = 1; i < counter; ++i) {
        ++it;
    }
    for (that = L.begin(); that != L.end(); ++that) {
        P.insert_after(it, *that);
    }
    
    //to see if the list was actually added in reverse
    
    // for (it = P.begin(); it != P.end(); ++it) {
    //     cout << *it << " ";
    // }
    // cout << endl;
}

template<typename Type>
void printLots (forward_list <Type> L, forward_list <int> P) {
    
    typename forward_list<Type>::iterator LIt;
    typename forward_list<int>::iterator PIt;
    int counter;
    int size = 0;
    
    for (LIt = L.begin(); LIt != L.end(); ++LIt) {
        size = size + 1;
    }
    
    for (PIt = P.begin(); PIt != P.end(); ++PIt) {
        counter = *PIt;
        if (counter >= size) {
            return;
        }
        for (LIt = L.begin(); counter != 0; ++LIt) {
            counter = counter - 1;
        }
        cout << *LIt << endl;
    }
}

// int main() {
//     // isPrime(4);
//     forward_list<int> myList = {4, 6, 8, 10, 11, 12, 13};
//     forward_list<int> yourList = {2, 3, 4};
    
//     listCopy(myList, yourList);
    
//     printLots(myList, yourList);
    
    
//     return 0;
// }